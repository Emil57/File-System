import java.io.*;
import java.util.Scanner;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;
public class Alumnos
{
public static Scanner sc=new Scanner(System.in);
public static Scanner leer=new Scanner(System.in);
static String Matricula, Nombres, Carrera, Paterno, Materno, Materia,carr,aux,aux2,aux3,aux4,aux5,aux6, carresp,matesp;
	public static void main(String args[]) throws IOException
	{
/* Diccionario de Datos

		==========================================================================================
		Variable................. Tipo de Datos...............Uso de la Variable
		==========================================================================================
		i........................ integer..................... Variable que controla a ciertos for
		z........................ integer..................... Tamano del arreglo
		k........................ integer..................... Variable que me permite seguir pidiendo atributos
		cont..................... integer..................... Variable que guarda el total de alumnos registrados
		cont2.................... integer..................... Variable que valida las carreras
		cont3.................... integer..................... Variable que valida las materias
		cont4.................... integer..................... Variable que cuenta los alumnos en la carrera seleccionada
		cont5.................... integer..................... Variable que cuenta los alumnos en la materia seleccionada
		NoF...................... integer..................... Variable que cuenta los alumnos que no estan en la carrera y materia seleccionada
		ax....................... boolean..................... Boolean que controla las carreras
		ax2...................... boolean..................... Boolean que controla las materias
		carr[]................... string...................... Arreglo que guarda las carreras
		mat[].................... string...................... Arreglo que guarda las materias
		prueba................... Boolean..................... Variable de comprobaci�n de una condicion cumplida
		op....................... Byte........................ Variable para moverse por el case principal
		op1...................... Byte........................ Variable para desplazarse por case cambios
		op2...................... Byte........................ Variable para moverse por CASE visualizacion
		op4...................... Byte........................ Variable para seleccionar el acomodo en el reporte
		save..................... Integer..................... Variable para guardar posici�n buscada
		size..................... Integer..................... Tamaño del arreglo con datos
		a........................ String...................... Variable de almacenamiento
		Matricula................ String...................... Variable que guarda matricula ingresada
		Carrera.................. String...................... Variable que guarda carrera ingresada
		Nombres.................. String...................... Variable que guarda nombre(s) ingresado(s)
		Paterno.................. String...................... Variable que guarda apellido paterno
		Materno.................. String...................... Variable que guarda apellido materno
		datos[].................. Plebes...................... El arreglo es del tipo del objeto
		aux...................... String...................... Variable que guarda datos temporalmente
		aux2..................... String...................... Variable que guarda datos temporalmente
		aux3..................... String...................... Variable que guarda datos temporalmente
		aux4..................... String...................... Variable que guarda datos temporalmente
		aux5..................... String...................... Variable que guarda datos temporalmente
		aux6..................... String...................... Variable que guarda datos temporalmente
		kk....................... integer..................... Variable que controla el for
		opciones[]............... String...................... Arreglo de datos desplegado en menu principal
		opciones1[].............. String...................... Arreglo de opciones desplegado en cambios
		opciones2[].............. String...................... Arreglo de datos desplegado en reportes
		opciones3[].............. String...................... Arreglo de datos desplegado en opciones de reportes
		impresion................ String...................... Variable que guarda datos para mostrar desplegada en visualizacion y reportes*/
		
	
	int op=0,op4=0,op3=0,op5=0; //variables para desplazarse sobre diferentes menús
	int i=0, z=15,k=0,cont=0,op1,size=0,cont2=0,cont3=0,save=0,cont4=0,cont5=0; 
	boolean prueba=true, ax=true,ax2=true;
		
 	//declaracion del objeto
	Plebes datos[]=new Plebes[15];
 	Plebes datos2[]=new Plebes[15];
 	String Matricula, Carrera="", Nombres, Paterno, Materno, Materia=""; // strings para el objeto
 	
 	
 	String[] carr={"ICC","IDGD","IMEC","IM"}; //arreglo para carreras existentes 
 	String[] mat={"Calculo","Estatica","Programacion","Fisica"}; //arreglo para materias
 	String [] opciones = {"Altas","Bajas","Cambios","Visualizacion","Reportes","Escribir ","Leer","Salir"}; //opciones del menu
	String [] opciones1= {"Nombre(s)","Paterno","Materno","Materia","Carrera"}; 
	String [] opciones2= {"Carrera especifica","Materia específica", "Salir"};
	String [] opciones3= {"Por Matricula", "Orden Alfabetico-Apellido","Salir"};
	String impresion ="";
	
	//variables para archivos (lectura y escritura)
	String ruta = "archivo.txt";
	File archivo = new File(ruta);
	
	//Empieza programa
		for(i=0; i<z; i++)
		{
		//creamos 15 espacios en el objeto
		datos[i]=new Plebes();
		datos2[i]=new Plebes();
	 	}
	// bloque para del menu de opciones 
	do {
		op=JOptionPane.showOptionDialog(null, "¿Que desea realizar?", "PROYECTO ABCVR", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, opciones, 0);//muestra opciones 
		switch (op)
		{
		case 0: //empieza altas
			prueba=false; //reiniciamos variables
			Matricula = JOptionPane.showInputDialog(null, "Ingresa nueva matricula: "); 
			do	{//validamos que no permita espacios vacíos ni otros caracteres
				try {
					if (Matricula.isEmpty()) //preguntamos si esta vacio la variable
					{
						Matricula=JOptionPane.showInputDialog("ERROR. Ingresa una matricula: ");	
					}
					else
					{
						save=Integer.parseInt(Matricula);
						prueba=true;	// sale del try
					}
					
				} catch(NumberFormatException err)
				{
					Matricula= JOptionPane.showInputDialog(null, "ERROR. Solo numeros. Intenta de nuevo: ", "ERROR", JOptionPane.DEFAULT_OPTION);				
				}
			} while(prueba==false); //ciclo se repite hasta que ingrese alguna matricula
				i=0;
				while(i<z-1) //i = 15
				{	// validamos que no haya matriculas iguales
					if(Matricula.equalsIgnoreCase(datos[i].getMatricula()))
					{
						i=0;
						JOptionPane.showMessageDialog(null, "Ingresa otra matricula, esta ya existe. ", "ALTAS", JOptionPane.CLOSED_OPTION);//si existe, manda el aviso
						Matricula = JOptionPane.showInputDialog(null, "Ingresa matricula nuevamente: ");
						cont5=1;
						continue;
					}
					i++;
				}

				k=1;
					if(k!=0)
					{
						datos[cont].setMatricula(Matricula);
						Nombres = JOptionPane.showInputDialog("Nombres: ");
						prueba=false;
						while (prueba==false)
						if (Nombres.isEmpty() | Nombres.contains(" "))
						{
							Nombres=JOptionPane.showInputDialog("ERROR. No dejes espacios en blanco: ");	
						}
						else
						{
							prueba=true;	
						}
						datos[cont].setNombres (Nombres);
						
						
						Paterno = JOptionPane.showInputDialog("Apellido Paterno: ");
						prueba=false;
						while (prueba==false)
						if (Paterno.isEmpty() | Paterno.contains(" "))
						{
							Paterno=JOptionPane.showInputDialog("ERROR. No dejes espacios en blanco: ");	
						}
						else
						{
							prueba=true;	
						}
						datos[cont].setPaterno (Paterno);
						
						
						Materno = JOptionPane.showInputDialog("Apellido Materno: ");
						prueba=false;
						while (prueba==false)
						if (Materno.isEmpty() | Materno.contains(" "))
						{
							Materno=JOptionPane.showInputDialog("ERROR. No dejes espacios en blanco: ");	
						}
						else
						{
							prueba=true;	
						}
						datos[cont].setMaterno (Materno);
						
						
						ax=true; ax2=true; //reiniciamos variables
						while(ax){ //bloque para invalidar espacios en blanco
						Carrera =JOptionPane.showInputDialog("Escribe carrera (ICC, IM, IMEC, IDGD): ");
						prueba=false; //variable reiniciada
						
						//bloque para invalidar espacios en blanco 
						while (prueba==false)
						if (Carrera.isEmpty() | Carrera.contains(" "))
						{
							Carrera=JOptionPane.showInputDialog("ERROR. No dejes espacios en blanco: ");	
						}
						else
						{
							prueba=true;	
						}
						
						cont2=0; cont3=0;
						for(i=0;i<4;i++)
						{
							if((Carrera.equalsIgnoreCase(carr[i]))==false)
							{
								cont2++;
							}
						}
						if(cont2!=3)
						{
							JOptionPane.showMessageDialog(null, "ERROR. Carrera invalida. Intenta de nuevo. ");
						}
						else
						{
							ax=false;
						}
					} 
					datos[cont].setCarrera (Carrera);
					// mismo bloque pero para materia
						while(ax2)
						{
							Materia = JOptionPane.showInputDialog(null, "Escribe materia (calculo, estatica, programacion o fisica): ");
							prueba=false;
							while (prueba==false)
							if (Materia.isEmpty() | Materia.contains(" "))
							{
								Materia=JOptionPane.showInputDialog("ERROR. No dejes espacios en blanco: ");	
							}
							else
							{
								prueba=true;	
							}

							cont2=0;
							cont3=0;
							for(i=0;i<4;i++)
							{
								if((Materia.equalsIgnoreCase(mat[i]))==false)
								{
									cont3++;
								}
							}
							if(cont3!=3)
							{
								JOptionPane.showMessageDialog(null, "ERROR. Materia invalida. Intenta otra vez. ");
							}
							else
							{
								ax2=false;
							}
						}
						datos[cont].setMateria (Materia);
					}
			cont++;
		break; //termina altas

		case 1: //bajas
			prueba=false; //reiniciamos variables
			Matricula=JOptionPane.showInputDialog(null, "Escribe matricula: ", "Bajas", JOptionPane.DEFAULT_OPTION); // pedimos la matricula
			for(i=0; i<=cont; i++)
				{
					if(Matricula.equalsIgnoreCase(datos[i].getMatricula()))
						{
						JOptionPane.showMessageDialog(null, "Eliminaste datos de matricula "+datos[i].getMatricula(), "Bajas", JOptionPane.INFORMATION_MESSAGE);

						//procedemos a eliminar los datos
						Matricula= null;
						datos[i].setMatricula(Matricula);
						Nombres= null;
						datos[i].setNombres (Nombres);
						Paterno = null;
						datos[i].setPaterno (Paterno);
						Materno = null;
						datos[i].setMaterno (Materno);
						Carrera = null;
						datos[i].setCarrera (Carrera);
						Materia = null;
						datos[i].setCarrera (Materia);

						//intercambiamos posiciones de datos que pusimos en 0 con los datos en la posicion final
						datos[i].setMatricula(datos[cont].getMatricula());
						datos[i].setNombres(datos[cont].getNombres());
						datos[i].setPaterno(datos[cont].getPaterno());
						datos[i].setMaterno(datos[cont].getMaterno());
						datos[i].setCarrera(datos[cont].getCarrera());
						datos[i].setMateria(datos[cont].getMateria());

						cont--; //decrementamos el total de estudiantes (datos)
						prueba=true;
						break;

						} //if
				}// for
				if (prueba == false) //en caso de que no se encuentra la matricula
					{
					JOptionPane.showMessageDialog(null, "ERROR. Matricula inexistente, prueba de nuevo. ", "Bajas", JOptionPane.WARNING_MESSAGE);
			}
		break; //termina bajas

		case 2: //empieza cambios o modificaciones (excepto matricula)
			prueba=false; //reiniciamos variable
			JOptionPane.showMessageDialog(null, "CAMBIOS"); //aviso
			if (cont>0) //si cont es menor o igual a 0 (empieza por default en 0), no entra, debido a que no hay nada de datos
			{
				op1= JOptionPane.showOptionDialog(null, "¿Que deseas hacer?", "Cambios", JOptionPane.DEFAULT_OPTION, JOptionPane.DEFAULT_OPTION, null, opciones1, null); //muestra opciones en menú 
				Matricula=JOptionPane.showInputDialog(null, "Ingresa matricula: ", "Cambios",	 JOptionPane.INFORMATION_MESSAGE); // pedimos la matricula
				for(i=0; i<=size; i++)
				{
					if(Matricula.equalsIgnoreCase(datos[i].getMatricula())) //verificamos que la matricula exista para realizar modificaciones
					{
						save=i;//guardamos la posicion donde haremos la modificacion
						prueba=true;
						i=size+1; //sale del ciclo for
					}
				}

				if (prueba==true)//verificamos si la matricula existió
				{
					switch (op1) //menu de opciones para cambios de cualquier tipo (excepto matricula)
					{
					case 0: // nombres
					Nombres=JOptionPane.showInputDialog(null, "Nuevo(s) Nombre(s): ", "Cambios", JOptionPane.INFORMATION_MESSAGE);
					prueba=false; // variable reiniciada 
					//bloque para invalidar espacios en blanco
					while (prueba==false)
					if (Nombres.isEmpty() | Nombres.contains(" "))
					{
						Nombres=JOptionPane.showInputDialog("ERROR. No dejes espacios en blanco: ");	
					}
					else
					{
						prueba=true;	
					}
					datos[save].setNombres(Nombres);
					break; //termina cambio de nombres

					case 1:// apellido paterno
					Paterno=JOptionPane.showInputDialog(null, "Nuevo ape. Paterno: ", "Cambios", JOptionPane.INFORMATION_MESSAGE);
					prueba=false;
					while (prueba==false)
					if (Paterno.isEmpty() | Paterno.contains(" "))
					{
						Paterno=JOptionPane.showInputDialog("ERROR. No dejes espacios en blanco: ");	
					}
					else
					{
						prueba=true;	
					}
					datos[save].setPaterno(Paterno);
					break; //termina cambio de paterno

					case 2: //apellido materno
					Materno=JOptionPane.showInputDialog(null, "Nuevo Ape. Materno: ", "Cambios", JOptionPane.INFORMATION_MESSAGE);
					prueba=false;
					while (prueba==false)
					if (Materno.isEmpty() | Materno.contains(" "))
					{
						Materno=JOptionPane.showInputDialog("ERROR. No dejes espacios en blanco: ");	
					}
					else
					{
						prueba=true;	
					}
					datos[save].setMaterno(Materno);
					break; //termina cambio de materno

					case 3: //materia
					prueba=false; //reiniciamos variables	
					// bloque para validar el cambio solo para las materias existentes
					do 	{
						Materia=JOptionPane.showInputDialog(null, "Nueva Materia: ", "Cambios", JOptionPane.INFORMATION_MESSAGE); //pedimos materia
						while (prueba==false)
						if (Materia.isEmpty() | Materia.contains(" "))
						{
							Materia=JOptionPane.showInputDialog("ERROR. No dejes espacios en blanco: ");	
						}
						else
						{
							prueba=true;	
						}
						prueba=false;
						for (i=0; i<4; i++)
						{
							if (Materia.equalsIgnoreCase(mat[i])) //buscamos si es la nueva materia esta permitida 
							{	
								datos[save].setCarrera(Materia); //asignamos 
								prueba=true; //marcamos la entrada
								break;
							}
						}
						if (prueba==false) //revisamos la entrada
						{
							JOptionPane.showMessageDialog(null, "ERROR. Materia invalida, intenta de nuevo");//mensaje de advertencia
						}
					} while(prueba==false); //se realiza hasta que la materia sea válida
					break; // termina cambio de materia
					
					case 4: //carrera 
						prueba=false; // reiniciamos variables
						// bloque para validar el cambio solo para las materias existentes
						do 	{
							Carrera =JOptionPane.showInputDialog(null, "Nueva Carrera: ", "Cambios", JOptionPane.INFORMATION_MESSAGE);
							while (prueba==false)
							if (Carrera.isEmpty() | Carrera.contains(" "))
							{
								Carrera=JOptionPane.showInputDialog("ERROR. No dejes espacios en blanco: ");	
							}
							else
							{
								prueba=true;	
							}
							prueba=false;
							for (i=0; i<4; i++)
							{
								if (Carrera.equalsIgnoreCase(carr[i])) //verificamos que la nueva carrera exista
								{	
									datos[save].setCarrera(Carrera); //existe, y por lo tanto, permitimos cambio
									prueba=true;
									break; //rompemos con el ciclo for
								}
							}
							if (prueba==false)
							{
								JOptionPane.showMessageDialog(null, "ERROR. Carrera invalida, intenta de nuevo");	
							}
						} while(prueba==false); //bloque que se realiza hasta que se ingrese una carrera válida
					break;	//termina cambio de carrera
				} 
			}
			else
			{
				JOptionPane.showMessageDialog(null, "ERROR. Matricula inexistente, intente de nuevo ", "CAMBIOS", JOptionPane.WARNING_MESSAGE, null); //aviso
			}
			}
			else
			{
			JOptionPane.showMessageDialog(null, "No hay datos disponibles", "CAMBIOS",JOptionPane.WARNING_MESSAGE); //aviso
			}
		break; //termina cambios

		case 3: //-------------VISUALIZACION --------------------------------------
			impresion=""; //reiniciamos variable 
			JOptionPane.showMessageDialog(null, "Elegiste Visualizacion", "VISUALIZACION", JOptionPane.INFORMATION_MESSAGE);		
			for (int j=0; j<=cont;j++) //ciclo para imprimir solamente los espacios con datos
			{
				if(datos[j].getMatricula()!=null) //si esta vacio un espacio (null), no imprime
				{	
					impresion+= "Posicion: "+j+"\n" + "Matricula: "+datos[j].getMatricula()+"\n" + "Nombre: "+datos[j].getNombres()+"\n" + "Apellido Paterno: "+datos[j].getPaterno()+"\n" + "Apellido Materno: "+datos[j].getMaterno()+"\n" + "Carrera: " +datos[j].getCarrera()+ "\n"+ "Materia: "+datos[j].getMateria()+"\n"; //mete datos en variable a visualizar
				}
			}
			JOptionPane.showMessageDialog(null, impresion); //muestra la visualizacion
		break; //termina visualizacion 

		
		case 4://-----------------------REPORTES----------------------------
			JOptionPane.showMessageDialog(null, "REPORTES", "PROYECTO ABCVR", JOptionPane.INFORMATION_MESSAGE); //aviso 
			
			op3= JOptionPane.showOptionDialog(null, "Elige una opcion: ", "REPORTES", JOptionPane.DEFAULT_OPTION, JOptionPane.DEFAULT_OPTION, null, opciones2, 0); //menu de opciones de reportes (visualizado) 
			switch(op3) //menu de opciones para tipos de reportes 
			{
				case 0: //
					cont4=0; //reiniciamos variables
					int noF = 0;
					carresp= JOptionPane.showInputDialog(null, "¿Que carrera quieres ver?. Disponibles: ICC, IMEC, IDGD, IM. " , "REPORTES", JOptionPane.QUESTION_MESSAGE); 
					for(int tx=0;tx<cont;tx++)
					{
						if(carresp.equalsIgnoreCase(datos[tx].getCarrera()))
						{
							datos2[tx-noF].setMatricula(datos[tx].getMatricula());
							datos2[tx-noF].setPaterno(datos[tx].getPaterno());
							datos2[tx-noF].setMaterno(datos[tx].getMaterno());
							datos2[tx-noF].setNombres(datos[tx].getNombres());
							datos2[tx-noF].setMateria(datos[tx].getMateria());
							datos2[tx-noF].setCarrera(datos[tx].getCarrera());
							cont4++;
						}	
						else
						{
							noF++;//variable que evita el null entre datos que no sean null
						}
					}
					JOptionPane.showMessageDialog(null, "Reportes de Carrera Especifica", "REPORTES", JOptionPane.INFORMATION_MESSAGE);
					op4=JOptionPane.showOptionDialog(null, "Elige una opcion: ", "R. Carrera Especifica", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, opciones3, 0); 
					/*
					System.out.println("0...Reporte por matricula");
					System.out.println("1...Reporte por Orden alfabetico por apellido");
					System.out.println("2...Salida");*/
								switch(op4)
								{
									case 0:
										for(int y=0;y<cont4;y++)
										{
											for(int xd=0;xd<cont4-1;xd++)
											{
												if(datos2[xd].getMatricula().compareToIgnoreCase(datos2[xd+1].getMatricula())>0) //Compara matriculas y las acomoda
												{
													aux=datos2[xd].getMatricula();
													datos2[xd].setMatricula(datos2[xd+1].getMatricula());
													datos2[xd+1].setMatricula(aux);

													aux2=datos2[xd].getNombres();
													datos2[xd].setNombres(datos2[xd+1].getNombres());
													datos2[xd+1].setNombres(aux2);

													aux3=datos2[xd].getPaterno();
													datos2[xd].setPaterno(datos2[xd+1].getPaterno());
													datos2[xd+1].setPaterno(aux3);

													aux4=datos2[xd].getMaterno();
													datos2[xd].setMaterno(datos2[xd+1].getMaterno());
													datos2[xd+1].setMaterno(aux4);

													aux5=datos2[xd].getCarrera();
													datos2[xd].setCarrera(datos2[xd+1].getCarrera());
													datos2[xd+1].setCarrera(aux5);

													aux6=datos2[xd].getMateria();
													datos2[xd].setMateria(datos2[xd+1].getMateria());
													datos2[xd+1].setMateria(aux6);
												}
											}
										}
										impresion="";  //se reinicia la variable para visualizar 
										for ( int kx=0; kx<cont4;kx++)
										{
											if(datos2[kx].getMatricula()!=null)
											{
												impresion+= "Carrera: " +datos[kx].getCarrera()+ "\n"+ "Posicion: "+kx+"\n" + "Matricula: "+datos[kx].getMatricula()+"\n" + "Nombre: "+datos[kx].getNombres()+"\n" + "Apellido Paterno: "+datos[kx].getPaterno()+"\n" + "Apellido Materno: "+datos[kx].getMaterno()+"\n" + "Materia: "+datos[kx].getMateria()+"\n";

											}
										}
										JOptionPane.showMessageDialog(null, impresion, "Visualizacion", JOptionPane.DEFAULT_OPTION);
									break;

									case 1:
										for(int y=0;y<cont4;y++) //Se acomodan por apellido
										{
											for(int xd=0;xd<cont4-1;xd++)
											{
												if(datos2[xd].getPaterno().compareToIgnoreCase(datos2[xd+1].getPaterno())>0)
												{
													aux=datos2[xd].getMatricula();
													datos2[xd].setMatricula(datos2[xd+1].getMatricula());
													datos2[xd+1].setMatricula(aux);

													aux2=datos2[xd].getNombres();
													datos2[xd].setNombres(datos2[xd+1].getNombres());
													datos2[xd+1].setNombres(aux2);

													aux3=datos2[xd].getPaterno();
													datos2[xd].setPaterno(datos2[xd+1].getPaterno());
													datos2[xd+1].setPaterno(aux3);

													aux4=datos2[xd].getMaterno();
													datos2[xd].setMaterno(datos2[xd+1].getMaterno());
													datos2[xd+1].setMaterno(aux4);

													aux5=datos2[xd].getCarrera();
													datos2[xd].setCarrera(datos2[xd+1].getCarrera());
													datos2[xd+1].setCarrera(aux5);

													aux6=datos2[xd].getMateria();
													datos2[xd].setMateria(datos2[xd+1].getMateria());
													datos2[xd+1].setMateria(aux6);
												}
												else
												{
													if(datos2[xd].getPaterno().compareToIgnoreCase(datos2[xd+1].getPaterno())==0) //Si el apellido paterno es el mismo, compara maternos
													{
														if(datos2[xd].getMaterno().compareToIgnoreCase(datos2[xd+1].getMaterno())>0)
														{
															aux=datos2[xd].getMatricula();
															datos2[xd].setMatricula(datos2[xd+1].getMatricula());
															datos2[xd+1].setMatricula(aux);

															aux2=datos2[xd].getNombres();
															datos2[xd].setNombres(datos2[xd+1].getNombres());
															datos2[xd+1].setNombres(aux2);

															aux3=datos2[xd].getPaterno();
															datos2[xd].setPaterno(datos2[xd+1].getPaterno());
															datos2[xd+1].setPaterno(aux3);

															aux4=datos2[xd].getMaterno();
															datos2[xd].setMaterno(datos2[xd+1].getMaterno());
															datos2[xd+1].setMaterno(aux4);

															aux5=datos[xd].getCarrera();
															datos[xd].setCarrera(datos[xd+1].getCarrera());
															datos[xd+1].setCarrera(aux5);

															aux6=datos2[xd].getMateria();
															datos2[xd].setMateria(datos2[xd+1].getMateria());
															datos2[xd+1].setMateria(aux6);
														} // llave del if
														else
														{
															if(datos2[xd].getMaterno().compareToIgnoreCase(datos2[xd+1].getMaterno())==0) //Si los maternos son iguales, compara nombres
															{
																if(datos2[xd].getNombres().compareToIgnoreCase(datos2[xd+1].getNombres())>0)
																{
																	aux=datos2[xd].getMatricula();
																	datos2[xd].setMatricula(datos2[xd+1].getMatricula());
																	datos2[xd+1].setMatricula(aux);

																	aux2=datos2[xd].getNombres();
																	datos2[xd].setNombres(datos2[xd+1].getNombres());
																	datos2[xd+1].setNombres(aux2);
																					
																	aux3=datos2[xd].getPaterno();
																	datos2[xd].setPaterno(datos2[xd+1].getPaterno());
																	datos2[xd+1].setPaterno(aux3);
				
																	aux4=datos2[xd].getMaterno();
																	datos2[xd].setMaterno(datos2[xd+1].getMaterno());
																	datos2[xd+1].setMaterno(aux4);

																	aux5=datos2[xd].getCarrera();
																	datos2[xd].setCarrera(datos2[xd+1].getCarrera());
																	datos2[xd+1].setCarrera(aux5);

																	aux6=datos[xd].getMateria();
																	datos2[xd].setMateria(datos[xd+1].getMateria());
																	datos2[xd+1].setMateria(aux6);
																} // lave del if
															} // llave del if
														} // llave del else
													} // if
											} //ciclo del for
										} // ciclo for
									}
									impresion="";
									//visualizacion de datos pedidos 
									for ( int kx=0; kx<cont4;kx++) //AGREGAR ESTO
									{
										if(datos2[kx].getMatricula()!=null)
										{
											impresion+= "Carrera: " +datos[kx].getCarrera()+ "\n"+ "Posicion: "+kx+"\n" + "Matricula: "+datos[kx].getMatricula()+"\n" + "Nombre: "+datos[kx].getNombres()+"\n" + "Apellido Paterno: "+datos[kx].getPaterno()+"\n" + "Apellido Materno: "+datos[kx].getMaterno()+"\n" + "Materia: "+datos[kx].getMateria()+"\n";
											
										}
									}
									break;
									
									case 3:
									op4=3;
									break;
									
									default:  JOptionPane.showMessageDialog(null, "Opcion invalida. Ingrese otra.");
								}
			break;

			case 1:
				noF=0; cont5=0;
				matesp=JOptionPane.showInputDialog(null, "Introduce la Materia deseada para ver. Disponibles: Calculo, Estatica, Programacion y Fisica. ");
				for(int tx=0;tx<cont;tx++)
				{
					if(matesp.equalsIgnoreCase(datos[tx].getMateria()))
					{
						datos2[tx-noF].setMatricula(datos[tx].getMatricula());
						datos2[tx-noF].setPaterno(datos[tx].getPaterno());
						datos2[tx-noF].setMaterno(datos[tx].getMaterno());
						datos2[tx-noF].setNombres(datos[tx].getNombres());
						datos2[tx-noF].setMateria(datos[tx].getMateria());
						datos2[tx-noF].setCarrera(datos[tx].getCarrera());
						cont5++;
					}
					else
					{
						noF++;//variable que evita null entre datos que no son null
					}
				}
				JOptionPane.showMessageDialog(null, "REPORTE POR MATERIA ESPECIFICA");
				
				op5=JOptionPane.showOptionDialog(null, "Escoge una opcion",	"POR MATERIA ESPECIFICA", JOptionPane.DEFAULT_OPTION, JOptionPane.DEFAULT_OPTION, null, opciones3, 0);
				switch(op5)
				{
					case 0:
						for(int y=0;y<cont5;y++)
						{
							for(int xd=0;xd<cont5-1;xd++)
							{
								if(datos2[xd].getMatricula().compareToIgnoreCase(datos2[xd+1].getMatricula())>0) //Compara matriculas y las acomoda
								{
									aux=datos2[xd].getMatricula();
									datos2[xd].setMatricula(datos2[xd+1].getMatricula());
									datos2[xd+1].setMatricula(aux);
									aux2=datos2[xd].getNombres();
									datos2[xd].setNombres(datos2[xd+1].getNombres());
									datos2[xd+1].setNombres(aux2);
									aux3=datos2[xd].getPaterno();
									datos2[xd].setPaterno(datos2[xd+1].getPaterno());
									datos2[xd+1].setPaterno(aux3);
									aux4=datos2[xd].getMaterno();
									datos2[xd].setMaterno(datos2[xd+1].getMaterno());
									datos2[xd+1].setMaterno(aux4);
									aux5=datos2[xd].getCarrera();
									datos2[xd].setCarrera(datos2[xd+1].getCarrera());
									datos2[xd+1].setCarrera(aux5);
									aux6=datos2[xd].getMateria();
									datos2[xd].setMateria(datos2[xd+1].getMateria());
									datos2[xd+1].setMateria(aux6);
								}
							}
						}
						impresion="";
						JOptionPane.showMessageDialog(null, "REPORTE POR MATRICULA");						
						for ( int kx=0; kx<cont5;kx++)
						{
							if(datos2[kx].getMatricula()!=null)
							{
								impresion+= "Matricula: "+datos2[kx].getMatricula()+"\n"+ "Posicion: "+kx+"\n"+ "Nombre: "+datos2[kx].getNombres()+"\n" + "Apellido Paterno: "+datos2[kx].getPaterno()+"\n" + "Apellido Materno: "+datos2[kx].getMaterno()+"\n"+"Carrera: "+datos[kx].getCarrera()+"\n"+ "Materia: "+datos[kx].getMateria()+"\n";
							}
						}
						JOptionPane.showMessageDialog(null, impresion);
					break;

					case 1:
						for(int y=0;y<cont5;y++) //Se acomodan por apellido
						{
							for(int xd=0;xd<cont5-1;xd++)
							{
								if(datos2[xd].getPaterno().compareToIgnoreCase(datos2[xd+1].getPaterno())>0)
								{
								aux=datos2[xd].getMatricula();
								datos2[xd].setMatricula(datos2[xd+1].getMatricula());
								datos2[xd+1].setMatricula(aux);
								aux2=datos2[xd].getNombres();
								datos2[xd].setNombres(datos2[xd+1].getNombres());
								datos2[xd+1].setNombres(aux2);
								aux3=datos2[xd].getPaterno();
								datos2[xd].setPaterno(datos2[xd+1].getPaterno());
								datos2[xd+1].setPaterno(aux3);
								aux4=datos2[xd].getMaterno();
								datos2[xd].setMaterno(datos2[xd+1].getMaterno());
								datos2[xd+1].setMaterno(aux4);
								aux5=datos2[xd].getCarrera();
								datos2[xd].setCarrera(datos2[xd+1].getCarrera());
								datos2[xd+1].setCarrera(aux5);
								aux6=datos2[xd].getMateria();
								datos2[xd].setMateria(datos2[xd+1].getMateria());
								datos2[xd+1].setMateria(aux6);
								}
								else
								{
									if(datos2[xd].getPaterno().compareToIgnoreCase(datos2[xd+1].getPaterno())==0) //Si el apellido paterno es el mismo, compara maternos
									{
										if(datos2[xd].getMaterno().compareToIgnoreCase(datos2[xd+1].getMaterno())>0)
										{
											aux=datos2[xd].getMatricula();
											datos2[xd].setMatricula(datos2[xd+1].getMatricula());
											datos2[xd+1].setMatricula(aux);
											aux2=datos2[xd].getNombres();
											datos2[xd].setNombres(datos2[xd+1].getNombres());
											datos2[xd+1].setNombres(aux2);
											aux3=datos2[xd].getPaterno();
											datos2[xd].setPaterno(datos2[xd+1].getPaterno());
											datos2[xd+1].setPaterno(aux3);
											aux4=datos2[xd].getMaterno();
											datos2[xd].setMaterno(datos2[xd+1].getMaterno());
											datos2[xd+1].setMaterno(aux4);
											aux5=datos[xd].getCarrera();
											datos[xd].setCarrera(datos[xd+1].getCarrera());
											datos[xd+1].setCarrera(aux5);
											aux6=datos2[xd].getMateria();
											datos2[xd].setMateria(datos2[xd+1].getMateria());
											datos2[xd+1].setMateria(aux6);
										}
										else
										{
											if(datos2[xd].getMaterno().compareToIgnoreCase(datos2[xd+1].getMaterno())==0) //Si los maternos son iguales, compara nombres
											{
												if(datos2[xd].getNombres().compareToIgnoreCase(datos2[xd+1].getNombres())>0)
												{
													aux=datos2[xd].getMatricula();
													datos2[xd].setMatricula(datos2[xd+1].getMatricula());
													datos2[xd+1].setMatricula(aux);
													aux2=datos2[xd].getNombres();
													datos2[xd].setNombres(datos2[xd+1].getNombres());
													datos2[xd+1].setNombres(aux2);
													aux3=datos2[xd].getPaterno();
													datos2[xd].setPaterno(datos2[xd+1].getPaterno());
													datos2[xd+1].setPaterno(aux3);
													aux4=datos2[xd].getMaterno();
													datos2[xd].setMaterno(datos2[xd+1].getMaterno());
													datos2[xd+1].setMaterno(aux4);
													aux5=datos2[xd].getCarrera();
													datos2[xd].setCarrera(datos2[xd+1].getCarrera());
													datos2[xd+1].setCarrera(aux5);
													aux6=datos[xd].getMateria();
													datos2[xd].setMateria(datos[xd+1].getMateria());
													datos2[xd+1].setMateria(aux6);
												}
											}
										}
									}
								}
							}
						}
						JOptionPane.showMessageDialog(null, "REPORTE POR APELLIDOS");
						impresion="";
						for ( int kx=0; kx<cont5;kx++)
						{
							if(datos2[kx].getMatricula()!=null)
							{
								impresion+= "Apellido Paterno: "+datos2[kx].getPaterno()+"\n" + "Apellido Materno: "+datos2[kx].getMaterno()+"\n" +"Nombre: "+datos2[kx].getNombres()+"\n"+ "Matricula: "+datos2[kx].getMatricula()+"\n" +"Carrera: "+datos[kx].getCarrera()+ "\n"+ "Materia: "+datos[kx].getMateria()+ "n" + "Posicion: "+kx+"\n" ;
							}
						}
						JOptionPane.showMessageDialog(null, impresion);
					break;
						
					case 2:
						op5=3;
					break;
						
					default: JOptionPane.showMessageDialog(null, "Opcion invalida. Ingrese otra.");
				}
			break;

			case 2:
			op3=3;
			break;
			default: JOptionPane.showMessageDialog(null, "Opcion invalida. Ingrese otra.");
		}

		break;

		case 5:
			//Escritura de archivos

			BufferedWriter bw;
			if(archivo.exists())
			{
				System.out.println("Ha habido problemas: El Archivo YA EXISTE");
				bw = new BufferedWriter(new FileWriter(archivo));
				bw.write("El fichero de texto ya estaba creado.\n");
			}
			else
			{
				System.out.println(
					"Hemos creado el archivo");
				bw = new BufferedWriter(new FileWriter(archivo));
				bw.write("Acabo de crear el fichero de texto.\n");
			}

        // Escribimos 15 registros de datos
        for (int o = 0; o<cont; o++)
        {
			bw.write(datos[o].getMatricula() + "|" + datos[o].getNombres() + "|" + datos[o].getPaterno()+"|"+datos[o].getMaterno()+"|"+datos[o].getCarrera()+"|"+datos[o].getMateria()+"\n")	;
		}
		bw.close();
		break;
		
		case 6:
			//Lectura de archivo
			System.out.println("lectura de archivos");
		BufferedReader br = new BufferedReader(new FileReader(archivo));


			if(archivo.exists()) {
				System.out.println(

					"Se procedera a leer el archivo" );


			} else
			{
				System.out.println(
					"NO EXISTE EL ARCHIVO. \n ");
				br.close();
				return;
			}



        // Leemos los registros completos 15 registros de datos
        // recuerdes asi son los datos el pipeline es el delimitador
		// 1|123456|abcdefghjiklmno|abcdefghijoklm|

		String Linea = null;
		String [] campos = new String [6];
		int jk=0;
		Linea = br.readLine(); // la primer linea con solo texto
		System.out.println("lei encabezado " +  Linea);
		while(Linea!=null)
        {

//			 leemos la lindea de datos
			Linea = br.readLine();
			if(Linea==null)
				break;
			System.out.println("lei renglon " + jk + " " + Linea);
			campos=Linea.split("\\|");
			System.out.println("lei campos " + campos [0] + " "+
			                                   campos [1] + " " +
			                                   campos [2] + " " +
			                                   campos [3] + " " +
			                                   campos [4] + " " +
			                                   campos [5] + " " );
			datos[jk].setMatricula(campos[0]);
			datos[jk].setNombres(campos[1]);
			datos[jk].setPaterno(campos[2]);
			datos[jk].setMaterno(campos[3]);
			datos[jk].setCarrera(campos[4]);
			datos[jk].setMateria(campos[5]);
			jk++;
		}
		break; 
		
		case 7:
		op=7;
		break;
		default: JOptionPane.showMessageDialog(null, "Opcion invalida. Ingrese otra.");
		}
	}while (op!=7);
}//main
}//alumnos
