public class Plebes
{
	  String matricula, nombres, paterno, materno, carrera, materia;

public Plebes()
{
}
	public Plebes (String matr, String nomb, String apeP, String apeM, String carr, String mate)
	{
		this.matricula=matr;
		this.nombres=nomb;
		this.paterno=apeP;
		this.materno=apeM;
		this.carrera=carr;
		this.materia=mate;
	}
	public void setMatricula (String matA)
	{
		this.matricula=matA;
	}
public String getMatricula()
       {
           return matricula;
       }
       public void setNombres (String nomb)
       {
           this.nombres = nomb;
       }
       public String getNombres()
       {
           return nombres;
       }
       public void setPaterno (String apeP)
       {
           this.paterno = apeP;
       }
       public String getPaterno()
       {
           return paterno;
       }
       public void setMaterno (String apeM)
       {
           this.materno = apeM;
       }
       public String getMaterno()
       {
           return materno;
       }

       public void setCarrera (String carr)
       {
           this.carrera = carr;
       }
       public String getCarrera()
       {
           return carrera;
       }
       public void setMateria (String mate)
	   {
	   this.materia = mate;
	   }
	   public String getMateria()
	   {
	  	 return materia;
       }
}